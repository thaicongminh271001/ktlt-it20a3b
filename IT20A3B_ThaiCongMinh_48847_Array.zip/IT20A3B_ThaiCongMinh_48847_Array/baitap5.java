import java.util.Scanner;
public class baitap5 {
    //khong biet lam :((
}
